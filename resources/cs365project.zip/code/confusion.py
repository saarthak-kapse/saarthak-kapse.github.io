# for row in range(10):
#         for column in range(10):
#             color = WHITE
#             if confMatrix[row,column] == 1:
#                 color = GREEN
#             pygame.draw.rect(screen,
#                              color,
#                              [(margin+width)*column+margin,
#                               (margin+height)*row+margin,
#                               width,
#                               height])

import pygame
import numpy
import pickle
import pdb
import sys


def printConfMatrix(grid,num):
    # Define some colors
    BLACK    = (   0,   0,   0)
    WHITE    = ( 255, 255, 255)
    GREEN    = (   0, 255,   0)
    RED      = ( 255,   0,   0)

    # This sets the width and height of each grid location
    width  = 20
    height = 20

    # This sets the margin between each cell
    margin = 5

    # Initialize pygame
    pygame.init()

    # Set the height and width of the screen
    size = [255, 255]
    screen = pygame.display.set_mode(size)

    # Set title of screen
    pygame.display.set_caption("Array Backed Grid")
    
    # Set the screen background
    screen.fill(WHITE)

    # Draw the grid
    for row in range(10):
        for column in range(10):
            color = (WHITE[0]-grid[row,column]*10,WHITE[1]-grid[row,column]*10,WHITE[2]-grid[row,column]*10)
            pygame.draw.rect(screen,
                             color,
                             [(margin+width)*column+margin,
                              (margin+height)*row+margin,
                              width,
                              height])


    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
    pygame.image.save(screen, "confusionMatrix" + num + ".jpg")
    #pdb.set_trace()
    # Be IDLE friendly. If you forget this line, the program will 'hang'
    # on exit.
    #pygame.quit()


f = open("confusion" + sys.argv[1] + ".pickle",'r')
grid = pickle.load(f)

printConfMatrix(grid,sys.argv[1])
