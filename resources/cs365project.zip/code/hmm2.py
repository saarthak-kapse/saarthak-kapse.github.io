import numpy 
from features import mfcc
from sklearn import hmm
import os
import subprocess
import pickle
from scipy.fftpack import fft

def read_wav(filename):
    bits_per_sample = '16'
    cmd = ['sox',filename,'-t','raw','-e','unsigned-integer','-L','-c','1','-b',bits_per_sample,'-','pad','0','30.0','rate','22050.0','trim','0','30.0']
    cmd = ' '.join(cmd)
    print cmd
    raw_audio = numpy.fromstring(subprocess.Popen(cmd,stdout=subprocess.PIPE,shell=True).communicate()[0],dtype='uint16')
    max_amp = 2.**(int(bits_per_sample)-1)
    raw_audio = (raw_audio- max_amp)/max_amp
    return raw_audio

dataset_dir = "./dataset_dir/audio/"
filenames = []
fs = 22050 #Frames per second

for foldername in os.listdir(dataset_dir):
	for filename in os.listdir(dataset_dir+foldername):
		filenames.append([foldername,filename])

mfcc_feats = numpy.zeros((30000,13))
j = 0
if (raw_input('Calculate FFT values for HMM training ?[y/n]') == 'y'):
	for filename in filenames:
		file_dir = dataset_dir+filename[0]+'/'+filename[1]
		raw_audio = read_wav(file_dir)	
		mfcc_feat = mfcc(raw_audio,samplerate=22050,winlen=1,winstep=1)
		mfcc_feats[j*30:j*30+30,:] = mfcc_feat
		j+=1
	pickle.dump([filenames,mfcc_feats],open("HMMtrain.p","w"))

filenames,mfcc_feats = pickle.load(open("HMMtrain.p","r"))


if (raw_input('Train the model ?[y/n]') == 'y'):
	print "Fitting to HMM"
	n_components = 20
	model = hmm.GaussianHMM(n_components,covariance_type="diag",n_iter=1000)
	model.fit([mfcc_feats])
	print "Fitting complete"
	pickle.dump(model,open("HMMmodel.p","w"))
	
model = pickle.load(open("HMMmodel.p","r"))

#Any batch testing that you would like to do on the model

