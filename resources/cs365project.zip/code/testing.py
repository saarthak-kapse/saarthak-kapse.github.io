import os
import sys
import numpy
import theano
import pickle
from preprocessing import PreProcessor
from mlp import MLP
from sgd import SGD_Optimizer
from dataset import Dataset
import state
import pdb
import csv
import math
import subprocess
from spectrogram import SpecGram
from scipy.stats import mode
import pygame

def sigmoid(x,beta):
    for i in range(x.shape[1]):
        for j in range(x.shape[0]):
            try :
                x[j,i] = 1 / (1 + math.exp(-(x[j,i]+beta[i])))
            except OverflowError:
                x[j,i] = 0.
    return x


def calc_specgram(x,fs,winSize,):
    spec = SpecGram(x,fs,winSize)
    return spec.specMat

def read_wav(filename):
    bits_per_sample = '16'
    cmd = ['sox',filename,'-t','raw','-e','unsigned-integer','-L','-c','1','-b',bits_per_sample,'-','pad','0','30.0','rate','22050.0','trim','0','30.0']
    cmd = ' '.join(cmd)
    #print cmd
    raw_audio = numpy.fromstring(subprocess.Popen(cmd,stdout=subprocess.PIPE,shell=True).communicate()[0],dtype='uint16')
    max_amp = 2.**(int(bits_per_sample)-1)
    raw_audio = (raw_audio- max_amp)/max_amp
    return raw_audio

def getFeature(filePath):
    raw_audio = read_wav(filePath)
    spec_x = calc_specgram(raw_audio,22050,1024)
    return spec_x
    
def testNetwork(bp,gt,filePath):
    feature = getFeature(filePath)
    #hardcoded structure
    for i in range(4):
        feature = numpy.mat(feature) * numpy.mat(bp[i])
       # print feature
        #        feature = numpy.array(feature)[0]
        #        print feature.shape
        feature = sigmoid(feature,bp[i+4])
        #pdb.set_trace()

    #feature = numpy.mat(feature) * numpy.mat(bp[3])
    #feature = sum(numpy.array(feature))
#    print feature.shape
#pdb.set_trace()
    maxProbArg = [numpy.argmax(feature[i,:]) for i in range(feature.shape[0])]
    
   # pdb.set_trace()
    estimate = numpy.zeros((1,feature.shape[1]),numpy.float64)
    estimate = estimate[0]
    #pdb.set_trace()
    estimate[int(mode(maxProbArg)[0][0])] = 1
    #pdb.set_trace()

    confMatrix[numpy.argmax(gt),:] = confMatrix[numpy.argmax(gt),:] + estimate
    
    if(not(min(gt - estimate))):
        print '1'
        return 1
    else:
        return 0

def printConfMatrix(grid):
    # Define some colors
    BLACK    = (   0,   0,   0)
    WHITE    = ( 255, 255, 255)
    GREEN    = (   0, 255,   0)
    RED      = ( 255,   0,   0)

    # This sets the width and height of each grid location
    width  = 20
    height = 20

    # This sets the margin between each cell
    margin = 5

    # Initialize pygame
    pygame.init()

    # Set the height and width of the screen
    size = [255, 255]
    screen = pygame.display.set_mode(size)

    # Set title of screen
    pygame.display.set_caption("Array Backed Grid")
    
    # Set the screen background
    screen.fill(BLACK)

    # Draw the grid
    for row in range(10):
        for column in range(10):
            color = WHITE
            if grid[row,column] == 1:
                color = GREEN
                pygame.draw.rect(screen,
                                 color,
                                 [(margin+width)*column+margin,
                                  (margin+height)*row+margin,
                                  width,
                                  height])


    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # Be IDLE friendly. If you forget this line, the program will 'hang'
    # on exit.
    pygame.quit()
                           

## confusion matrix
confMatrix = numpy.zeros((10,10))        
        
## set base path
basePath = '/home/amlan/study/cs365/Project/ICASSP-MLP-Code-master/dataset_dir/'
gtPath = '/home/amlan/study/cs365/Project/ICASSP-MLP-Code-master/dataset_dir/'
    
## import ground truth
gt = pickle.load(open(os.path.join(basePath,'lists/ground_truth.pickle'),"rb"))

## import best parameters
bp = pickle.load(open(os.path.join(basePath,'best_params.pickle'),"rb"))

## import test set
with open(os.path.join(basePath,'lists/test_1_of_1.txt')) as csvfile:
    reader = csv.reader(csvfile, delimiter = '\t')
    posCount = 0
    count = 0
    for row in reader:
        temp = row[0].split('/')
        filePath = os.path.join(basePath, 'audio/'+ temp[len(temp)-2] + '/' + temp[len(temp)-1])
        gtTemp = gt[os.path.join(gtPath,'audio/'+ temp[len(temp)-2] + '/' + temp[len(temp)-1])]
        posCount = posCount + testNetwork(bp,gtTemp,filePath)
        count = count + 1
        print count

print posCount/(1.0*count)
print confMatrix
f = open('confusion' + sys.argv[1] + '.pickle','wb')
pickle.dump(confMatrix,f)
#printConfMatrix(confMatrix)
pdb.set_trace()


'''
class tester():
	def __init__(self,state):
		self.state = state
		self.dataset_dir = self.state.get('dataset_dir','')
		self.list_dir = os.path.join(self.dataset_dir,'lists')
		self.lists = {}
		self.lists['train'] = os.path.join(self.list_dir,'train_1_of_1.txt')
self.lists['valid'] = os.path.join(self.list_dir,'valid_1_of_1.txt')
		self.lists['test'] = os.path.join(self.list_dir,'test_1_of_1.txt')
		self.preprocessor = PreProcessor(self.dataset_dir) 
		print 'Preparing train/valid/test splits'
		self.preprocessor.prepare_fold(self.lists['train'],self.lists['valid'],self.lists['test'])
		self.data = self.preprocessor.data
		self.targets = self.preprocessor.targets
		
	def test(self,):
		print 'Starting testing'
		print 'Initializing test dataset.'
		self.batch_size = self.state.get('batch_size',20)
		train_set = Dataset([self.data['test']],
                                    batch_size=self.batch_size,
                                    targets=[self.targets['test']])
                return train_set
		
                
                
if __name__=='__main__':
	state = state.get_state()
	classify = tester(state)
	set = classify.test()
'''
