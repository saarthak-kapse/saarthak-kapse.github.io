from sklearn.ensemble import RandomForestClassifier 
import numpy as np
import pickle
from sklearn import hmm

#Load HMM model and filenames
model = pickle.load(open("HMMmodel.p","r"))
filenames,FFT = pickle.load(open("HMMtrain.p","r"))

model2 = RandomForestClassifier(n_estimators=10)
X_train = np.zeros((950,10))
Y_train = []

X_test = np.zeros((50,10))
Y_test = []
i=0
j=0
k=0
for filename in filenames:
	print filename[1]
	feat = FFT[i*10:i*10+10,:]
	if(i%20 != 0):
		X_train[j,:] = model.decode(feat,algorithm="viterbi")[1]
		Y_train.append(filename[0])
		j+=1
	else:
		X_test[k,:] = model.decode(feat,algorithm="viterbi")[1]
		Y_test.append(filename[0])
		k+=1
	
	i+=1 
for j in range(0,9):
	X_train[:,j] = X_train[:,j] - X_train[:,j+1]
	X_test[:,j] = X_test[:,j] - X_test[:,j+1]

mean = X_train.mean(axis=0)
std = X_train.std(axis=0)
X_train = (X_train - mean) / std
mean = X_test.mean(axis=0)
std = X_test.std(axis=0)
X_test = (X_test - mean) / std

model2 = model2.fit(X_train,Y_train)

print model2.score(X_test,Y_test)

